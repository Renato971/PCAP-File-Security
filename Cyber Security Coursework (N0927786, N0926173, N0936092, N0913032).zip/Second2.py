from datetime import datetime
# Task 1 ••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••
f = open('CyberSecurity2022.pcap', 'rb')
out = open('out.txt', 'a+')
magic = bytes(f.read(4)).hex()

capture = {}

if magic == 'd4c3b2a1':

    majornumber = f.read(2)
    major = bytearray(majornumber)
    major.reverse()

    minornumber = f.read(2)
    minor = bytearray(minornumber)
    minor.reverse()

    times = f.read(4)
    time = bytearray(times)
    time.reverse()

    accutal = f.read(4)
    acc = bytearray(accutal)
    acc.reverse()

    snap = f.read(4)
    snaplen = bytearray(snap)
    snaplen.reverse()

    networks = f.read(4)
    network = bytearray(networks)
    network.reverse()
# Task 1 ending ∞∞∞∞∞∞∞∞∞∞∞∞∞∞∞∞∞∞∞∞∞∞§∞∞∞∞∞∞∞∞∞∞∞∞∞∞∞∞∞∞∞∞∞∞∞∞∞∞∞∞∞∞∞∞∞∞∞∞∞∞∞∞
# Task 2 ***************************************************
    for i in range (1, 100000):
        try:
            timeb = f.read(4)
            time1 = bytearray(timeb)
            time1.reverse()
            time2b =f.read(4)
            time2 = bytearray(time2b)
            time2.reverse()
            timestamp = float(str(int(bytes(time1).hex(), 16)) + '.' + str(int(bytes(time2).hex(), 16)))
            lenb1 = f.read(4)
            len1 = bytearray(lenb1)
            len1.reverse()
            len1dec = int(bytes(len1).hex(), 16)
            lenb2 = f.read(4)
            len2 = bytearray(lenb2)
            len2.reverse()
            packet_data = f.read(int(bytes(len1).hex(), 16))
            fields_packets = {i: {
                "Timestamp Epoch": timestamp,
                "Timestamp Date-Time": datetime.fromtimestamp(timestamp).strftime("%d-%m-%Y %H:%M:%S.%f"),
                "Captured Packet Length": len1dec,
                "Original Packet Length": int(bytes(len2).hex(), 16),
                "Source MAC": str(packet_data[:1].hex())+":"+str(packet_data[1:2].hex())+":"+str(packet_data[2:3].hex())+":"+str(packet_data[3:4].hex())+":"+str(packet_data[4:5].hex())+":"+str(packet_data[5:6].hex()),
                "Destination MAC": str(packet_data[6:7].hex())+":"+str(packet_data[7:8].hex())+":"+str(packet_data[8:9].hex())+":"+str(packet_data[9:10].hex())+":"+str(packet_data[10:11].hex())+":"+str(packet_data[11:12].hex()),
                "Source IP": str(int(packet_data[26:27].hex(), 16))+"."+str(int(packet_data[27:28].hex(), 16))+"."+str(int(packet_data[28:29].hex(), 16))+"."+str(int(packet_data[29:30].hex(), 16)),
                "Destination IP": str(int(packet_data[30:31].hex(), 16))+"."+str(int(packet_data[31:32].hex(), 16))+"."+str(int(packet_data[32:33].hex(), 16))+"."+str(int(packet_data[33:34].hex(), 16)),
                "Source Port": int(packet_data[34:36].hex(), 16),
                "Destination Port": int(packet_data[36:38].hex(), 16),
                'Payload': packet_data
            }}
            capture.update(fields_packets)
        except:
            continue
else:
    major = f.read(2)
    for i in range (1, 100000):
        try:
            time1 = f.read(4)
            time2 = f.read(4)
            timestamp = float(str(int(bytes(time1).hex(), 16)) + '.' + str(int(bytes(time2).hex(), 16)))
            len1 = f.read(4)
            len1dec = int(bytes(len1).hex(), 16)
            len2 = f.read(4)
            packet_data = f.read(len1dec)
            fields_packets = {i: {
                "Timestamp Epoch": timestamp,
                "Timestamp Date-Time": datetime.fromtimestamp(timestamp).strftime("%d-%m-%Y %H:%M:%S.%f"),
                "Captured Packet Length": len1dec,
                "Original Packet Length": int(bytes(len2).hex(), 16),
                'Payload': packet_data
            }}
            capture.update(fields_packets)
        except:
            continue
print('magic number. is: ' + magic)
print('major version: ' + bytes(major).hex())
print('minor version: ' + bytes(minor).hex())
print('timezone: ' + bytes(time).hex())
print('Accuracy timestamps: ' + (acc).hex())
print('SnapLen: ' + bytes(snaplen).hex())
print('Network: ' + (network).hex())

print("-----------------------------------------------------------------------------------------------------------")
print('Packet Data: \n')
print(capture[1])
print('Epoch time is: ', capture[1]["Timestamp Epoch"])
print('Actual time is: ', capture[1]["Timestamp Date-Time"])
print('Packet length is: ', capture[1]["Captured Packet Length"])
print('Source MAC is: ', capture[1]["Source MAC"])
print('Destination MAC is: ', capture[1]["Destination MAC"])
print('Source IP is: ', capture[1]["Source IP"])
print('Destination IP is: ', capture[1]["Destination IP"])
print('Source port is: ', capture[1]['Source Port'])
print('Destination port is: ', capture[1]['Destination Port'])
print("Host Name is: ", str(capture[1]['Payload'][len(capture[1]['Payload'])-16:len(capture[1]['Payload'])-7]))
print('\n')
print("--------------------------------------------------------------------------------------------------------------")
#task 2 ending ******************************************************
DNS = []
# Task 4 ************************************************************8
suggested = []
actual = []
searchstring = []

for i in range(1, len(capture)):
    if capture[i]['Destination Port'] == 53:
        DNS.append(str(capture[i]['Payload'][55:len(capture[i]['Payload'])-4]))

print(DNS)

for i in range (1, len(capture)):
    if 'Referer: http://www.bing.com/search?q=' in str(capture[i]['Payload']):
        start1 = str(capture[i]['Payload']).find('\\r\\nHost: ') + len('\\r\\nHost: ')
        end1 = str(capture[i]['Payload']).find('\\r\\nConnection: ')
        substring = str(capture[i]['Payload'])[start1:end1]
        start2 = str(capture[i]['Payload']).find('GET ') + len('GET ')
        end2 = str(capture[i]['Payload']).find(' HTTP/1.1\\r\\n')
        substring1 = str(capture[i]['Payload'])[start2:end2]
        actual.append(substring+substring1)
        suggested.append(str(capture[i]['Payload']))

    if 'Referer: http://www.bing.com/' in str(capture[i]['Payload']):

        start2 = str(capture[i]['Payload']).find('GET /search?q=') + len('GET /search?q=')
        end2 = str(capture[i]['Payload']).find('&qs=n&sp=')
        substring1 = str(capture[i]['Payload'])[start2:end2]
        searchstring.append(substring1.replace(" ", " "))


print("Searched Websites: ","http://www.bing.com/search?q=home+improvement+remodeling+your+kitchen")
print("\n")
print("Suggested Website: ",actual[len(suggested)-1:])
keyword = ('\n home \n improvement \n remodeling \n your \n kitchen')
keyword.split()
print("Key words searched:   ",keyword)

#Task 4  ending ************************************************************
